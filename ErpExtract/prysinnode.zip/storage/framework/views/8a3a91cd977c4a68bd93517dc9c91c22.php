

<?php $__env->startSection('title', 'Notificaciones'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-6">
    <div class="card-body">
        <h3>Notificaciones</h3>

        <table id="notificationsTable" class="table table-striped">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Mensaje</th>
                    <th>Fecha</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr data-id="<?php echo e($notification->id); ?>">
                    <td><?php echo e($notification->title); ?></td>
                    <td><?php echo e($notification->message); ?></td>
                    <td><?php echo e($notification->created_at->format('d/m/Y H:i')); ?></td>
                    <td>
                        <?php if($notification->read_at): ?>
                        <span class="badge bg-label-success">Leída</span>
                        <?php else: ?>
                        <span class="badge bg-label-danger">No leída</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(!$notification->read_at): ?>
                        <button class="btn btn-sm btn-info mark-as-read-btn" data-id="<?php echo e($notification->id); ?>">
                            Marcar como leída
                        </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">No hay notificaciones</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
    $(document).ready(function() {
        $('#notificationsTable').DataTable({
            responsive: true, // activa el responsive
            pageLength: 10, // número de filas por página            
            order: [
                [2, 'desc']
            ]
        });

        // Marcar notificación como leída vía AJAX
        $('.mark-as-read-btn').on('click', function() {
            let btn = $(this);
            let row = btn.closest('tr');
            let notificationId = btn.data('id');

            $.ajax({
                url: '/notifications/' + notificationId + '/read',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function() {
                    row.find('td:nth-child(4) span')
                        .removeClass('bg-label-danger')
                        .addClass('bg-label-success')
                        .text('Leída');
                    btn.remove();
                },
                error: function() {
                    alert('Error al marcar la notificación como leída.');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\WinNMP\WWW\B2BRegional\resources\views\notifications\index.blade.php ENDPATH**/ ?>
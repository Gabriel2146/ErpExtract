

<?php $__env->startSection('title', 'Tipos de Proveedor'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="card-title mb-4">Tipos de Proveedor</h4>
        <table id="tiposTable" class="table table-striped table-bordered nowrap" style="width:100%">
            <thead>
                <tr>
                    <th>Descripción</th>
                    <th>País</th>
                    <th>Clase Interlocutor</th>
                    <th>Socio Comercial</th>
                    <th>Cuenta Contable</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tipo->descripcion); ?></td>
                    <td><?php echo e($tipo->countryRelation->name ?? '-'); ?></td>
                    <td><?php echo e($tipo->claseInterlocutor); ?></td>
                    <td><?php echo e($tipo->socioComercial); ?></td>
                    <td><?php echo e($tipo->cuentaContable); ?></td>
                    <td><?php echo e($tipo->estado); ?></td>
                    <td>
                        <a href="<?php echo e(route('tipoproveedor.edit', $tipo->id)); ?>" class="btn btn-sm btn-primary">Editar</a>
                        <form action="<?php echo e(route('tipoproveedor.destroy', $tipo->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#tiposTable').DataTable({
            responsive: true,
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\WinNMP\WWW\B2BRegional\resources\views\content\proveedores\tipoproveedor.blade.php ENDPATH**/ ?>
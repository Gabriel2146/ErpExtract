<?php $__env->startSection('title', 'Blank layout - Layouts'); ?>

<?php $__env->startSection('content'); ?>
<h4 class="p-6">Blank Page</h4>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\WinNMP\WWW\B2BRegional\resources\views\content\layouts-example\layouts-blank.blade.php ENDPATH**/ ?>
<?php
$containerFooter = !empty($containerNav) ? $containerNav : 'container-fluid';
?>

<!-- Footer-->
<footer class="content-footer footer bg-footer-theme">
  <div class="<?php echo e($containerFooter); ?>">
    <div class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
      <div class="text-body">

      </div>
      <div class="d-none d-lg-inline-block">
        <div class="text-body">
          © <script>
            document.write(new Date().getFullYear())
          </script>, develop by <a href="#" class="footer-link"><?php echo e((!empty(config('variables.creatorName')) ? config('variables.creatorName') : '')); ?></a>
        </div>
      </div>
    </div>
  </div>
</footer>
<!--/ Footer--><?php /**PATH C:\WinNMP\WWW\B2BRegional\resources\views/layouts/sections/footer/footer.blade.php ENDPATH**/ ?>